"""
EVENTOS DE MENSAGENS
Manipula todas as mensagens e detecção proativa
"""

import discord
from discord.ext import commands
import re
from datetime import datetime

from core.config import config
from core.database import db
from core.logger import logger

async def setup(bot: commands.Bot):
    """Setup dos eventos de mensagens"""
    
    @bot.event
    async def on_message(message: discord.Message):
        """Sistema de detecção proativa CORRIGIDO - SEM AUTO-DELETE"""
        
        # Ignorar mensagens do próprio bot
        if message.author == bot.user:
            return await bot.process_commands(message)
        
        # Ignorar completamente bots da whitelist
        security_system = bot.systems.get('security')
        if security_system and message.author.bot:
            if message.author.id in security_system.whitelist_bots:
                return await bot.process_commands(message)
            else:
                return  # Apenas ignora outros bots, não deleta
        
        # 🛡️ DETECÇÃO PROATIVA - SEMPRE ATIVA
        detection_system = bot.systems.get('detection')
        if detection_system and not detection_system.modo_emergencia:
            # Detectar painéis suspeitos (apenas monitoramento)
            await detection_system.detectar_painel_suspeito(message)
            
            # Sistema de segurança - detectar flood (apenas monitoramento)
            await security_system.detectar_flood_mensagens(message)
        
        # ✅ CORREÇÃO: NÃO DELETAR MENSAGENS DURANTE RATE LIMIT
        rate_system = bot.systems.get('rate_limit')
        if rate_system and rate_system.rate_limit_active and not message.author.guild_permissions.administrator:
            # Permite mensagens normais, apenas bloqueia comandos
            if message.content.startswith(config.PREFIX):
                try:
                    await message.delete()
                except:
                    pass
                return
            else:
                return await bot.process_commands(message)
        
        # ✅ CORREÇÃO: CONVERSA NATURAL - SEM DUPLICAÇÃO
        # Se a mensagem é resposta ao bot
        if message.reference and message.reference.resolved:
            try:
                mensagem_respondida = await message.channel.fetch_message(message.reference.message_id)
                if mensagem_respondida.author.id == bot.user.id:
                    await message.channel.typing()
                    groq_ai = bot.systems.get('groq_ai')
                    if groq_ai:
                        resposta = await groq_ai.gerar_resposta(
                            message.content, 
                            user_id=message.author.id, 
                            contexto_conversa=True
                        )
                        await message.reply(resposta)
                    return await bot.process_commands(message)
            except:
                pass
        
        # ✅ CORREÇÃO: RESPOSTA ÀS MENCÕES - SEM DUPLICAÇÃO
        if bot.user.mentioned_in(message) and not message.mention_everyone:
            await message.channel.typing()
            
            mensagem_limpa = message.content.replace(f'<@{bot.user.id}>', '').strip()
            
            # Reconhecer o criador
            if any(nome in mensagem_limpa.lower() for nome in ['criador', 'creator', 'quem te fez', 'tzx']):
                resposta = "Meu criador é o **TzX** (@zrei_helper)! Ele manja de Python, Golang, é exploiter, white hat e atualmente quer ser bug bounty. É um cara fera! 🚀"
            elif mensagem_limpa:
                groq_ai = bot.systems.get('groq_ai')
                if groq_ai:
                    resposta = await groq_ai.gerar_resposta(
                        mensagem_limpa, 
                        user_id=message.author.id, 
                        contexto_conversa=True
                    )
                else:
                    resposta = "Eae! Tudo bem? Como posso ajudar?"
            else:
                resposta = "Eae! Tudo bem? Como posso ajudar?"
            
            await message.reply(resposta)
            return await bot.process_commands(message)
        
        # ✅ PROCESSAR COMANDOS NORMALMENTE
        await bot.process_commands(message)
    
    @bot.event
    async def on_message_delete(message: discord.Message):
        """Evento quando uma mensagem é deletada"""
        # Log de mensagem deletada
        from events.member_events import get_log_channel
        canal = await get_log_channel(message.guild, "moderacao")
        
        if canal and not message.author.bot:
            embed = discord.Embed(
                title="🗑️ MENSAGEM DELETADA",
                color=0xff0000,
                timestamp=datetime.now()
            )
            embed.add_field(name="👤 Autor", value=message.author.mention, inline=True)
            embed.add_field(name="📝 Canal", value=message.channel.mention, inline=True)
            
            if message.content:
                preview = message.content[:200] + "..." if len(message.content) > 200 else message.content
                embed.add_field(name="📄 Conteúdo", value=f"```{preview}```", inline=False)
            
            await canal.send(embed=embed)
    
    @bot.event
    async def on_message_edit(before: discord.Message, after: discord.Message):
        """Evento quando uma mensagem é editada"""
        # Ignorar bots e mensagens iguais
        if before.author.bot or before.content == after.content:
            return
        
        # Log de mensagem editada
        from events.member_events import get_log_channel
        canal = await get_log_channel(before.guild, "moderacao")
        
        if canal:
            embed = discord.Embed(
                title="✏️ MENSAGEM EDITADA",
                color=0xffff00,
                timestamp=datetime.now()
            )
            embed.add_field(name="👤 Autor", value=before.author.mention, inline=True)
            embed.add_field(name="📝 Canal", value=before.channel.mention, inline=True)
            
            if before.content:
                preview_before = before.content[:150] + "..." if len(before.content) > 150 else before.content
                embed.add_field(name="📄 Antes", value=f"```{preview_before}```", inline=False)
            
            if after.content:
                preview_after = after.content[:150] + "..." if len(after.content) > 150 else after.content
                embed.add_field(name="📄 Depois", value=f"```{preview_after}```", inline=False)
            
            await canal.send(embed=embed)
    
    @bot.event
    async def on_bulk_message_delete(messages: list):
        """Evento quando múltiplas mensagens são deletadas"""
        if not messages:
            return
        
        guild = messages[0].guild
        
        # Log de purge em massa
        from events.member_events import get_log_channel
        canal = await get_log_channel(guild, "moderacao")
        
        if canal:
            embed = discord.Embed(
                title="💥 PURGE EM MASSA",
                description=f"**{len(messages)} mensagens foram deletadas**",
                color=0xff0000,
                timestamp=datetime.now()
            )
            embed.add_field(name="📝 Canal", value=messages[0].channel.mention, inline=True)
            
            # Contar autores
            autores = {}
            for msg in messages:
                if not msg.author.bot:
                    autores[msg.author.name] = autores.get(msg.author.name, 0) + 1
            
            if autores:
                top_autores = "\n".join([f"• {autor}: {count} msgs" for autor, count in list(autores.items())[:5]])
                embed.add_field(name="👥 Autores", value=top_autores, inline=False)
            
            await canal.send(embed=embed)
            
            # Detecção de possível ataque
            detection_system = bot.systems.get('detection')
            if detection_system and len(messages) >= 50:
                await detection_system.ativar_protecao_emergencial(
                    guild, 
                    guild.me,  # Autor é o bot
                    f"PURGE_MASSA_{len(messages)}_MENSAGENS"
                )
    
    logger.info("✅ Eventos de mensagens configurados")