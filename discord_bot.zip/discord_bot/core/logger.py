"""
SISTEMA DE LOGGING
Configuração centralizada de logging
"""

import logging
import sys
from datetime import datetime
import os

def setup_logger(name: str = "discord_bot") -> logging.Logger:
    """Configura e retorna um logger"""
    
    # Criar logger
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    
    # Evitar logs duplicados
    if logger.handlers:
        return logger
    
    # Criar formato
    formatter = logging.Formatter(
        '%(asctime)s | %(levelname)s | %(name)s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Handler para console
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)
    
    # Handler para arquivo
    try:
        # Garantir que a pasta de logs existe
        if not os.path.exists('logs'):
            os.makedirs('logs')
        
        # Nome do arquivo com data
        date_str = datetime.now().strftime('%Y%m%d')
        file_handler = logging.FileHandler(
            f'logs/bot_{date_str}.log',
            encoding='utf-8'
        )
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(formatter)
        
        logger.addHandler(file_handler)
    except Exception as e:
        print(f"❌ Erro ao configurar file handler: {e}")
    
    logger.addHandler(console_handler)
    
    # Suprimir logs do discord muito verbosos
    logging.getLogger('discord').setLevel(logging.WARNING)
    logging.getLogger('websockets').setLevel(logging.WARNING)
    logging.getLogger('aiohttp').setLevel(logging.WARNING)
    
    return logger

# Logger global
logger = setup_logger()