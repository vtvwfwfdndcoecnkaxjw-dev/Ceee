"""
CORE DO BOT DISCORD
Inicialização e configuração principal
"""

import discord
from discord.ext import commands
import asyncio
import logging
from typing import List, Optional

from core.config import config
from core.database import db
from core.logger import setup_logger

# Configurar logging
logger = setup_logger()

class AdvancedBot(commands.Bot):
    """Classe principal do bot com todas as funcionalidades"""
    
    def __init__(self):
        # Configurar intents
        intents = discord.Intents.all()
        intents.typing = True
        intents.presences = True
        intents.members = True
        intents.message_content = True
        intents.guilds = True
        
        # Inicializar bot
        super().__init__(
            command_prefix=config.PREFIX,
            intents=intents,
            help_command=None,  # Customizaremos nosso próprio help
            case_insensitive=True
        )
        
        self.db = db
        self.config = config
        self.extensions_loaded = False
        
        # Sistemas serão inicializados após o bot estar pronto
        self.systems = {}
        
        logger.info("🤖 Bot inicializado")
    
    async def load_extensions(self) -> None:
        """Carrega todas as extensões do bot"""
        if self.extensions_loaded:
            return
        
        extensions = [
            # Sistemas
            'systems.security',
            'systems.detection',
            'systems.tickets',
            'systems.roles',
            'systems.invites',
            'systems.rate_limit',
            'systems.groq_ai',
            
            # Comandos
            'commands.admin.moderation',
            'commands.admin.channels',
            'commands.admin.roles',
            'commands.admin.security',
            'commands.admin.setup',
            'commands.utility.info',
            'commands.utility.tools',
            'commands.utility.pdf',
            'commands.utility.fun',
            'commands.cybersecurity.missions',
            'commands.cybersecurity.analysis',
            'commands.economy.points',
            'commands.economy.shop',
            
            # Eventos
            'events.member_events',
            'events.message_events',
            'events.channel_events',
            'events.reaction_events'
        ]
        
        loaded = 0
        failed = 0
        
        for extension in extensions:
            try:
                await self.load_extension(extension)
                loaded += 1
                logger.debug(f"✅ Extensão carregada: {extension}")
            except Exception as e:
                failed += 1
                logger.error(f"❌ Erro ao carregar {extension}: {e}")
        
        self.extensions_loaded = True
        logger.info(f"📦 Extensões carregadas: {loaded} OK, {failed} FALHAS")
    
    async def start_bot(self) -> None:
        """Inicia o bot"""
        if not config.validate_config():
            logger.error("❌ Configurações inválidas. Verifique seu arquivo .env")
            return
        
        try:
            await self.start(config.DISCORD_TOKEN)
        except discord.LoginFailure:
            logger.error("❌ Token do Discord inválido!")
        except Exception as e:
            logger.error(f"❌ Erro ao iniciar bot: {e}")
    
    async def setup_hook(self) -> None:
        """Hook de setup assíncrono"""
        logger.info("🔄 Configurando hook de inicialização...")
        
        # Criar tasks em background
        self.loop.create_task(self.background_tasks())
        
        # Inicializar sistemas
        await self.initialize_systems()
    
    async def initialize_systems(self) -> None:
        """Inicializa todos os sistemas do bot"""
        from systems.security import SistemaSegurancaMultifacetado
        from systems.detection import SistemaDeteccaoAvancada
        from systems.tickets import SistemaTickets
        from systems.roles import SistemaCargos
        from systems.invites import SistemaConvites
        from systems.rate_limit import RateLimitSystem
        from systems.groq_ai import GroqAI
        
        # Inicializar sistemas
        self.systems['security'] = SistemaSegurancaMultifacetado(self)
        self.systems['detection'] = SistemaDeteccaoAvancada(self)
        self.systems['tickets'] = SistemaTickets(self)
        self.systems['roles'] = SistemaCargos(self)
        self.systems['invites'] = SistemaConvites(self)
        self.systems['rate_limit'] = RateLimitSystem()
        self.systems['groq_ai'] = GroqAI(config.GROQ_API_KEY)
        
        # Inicializar sistemas assíncronos
        if hasattr(self.systems['security'], 'setup'):
            await self.systems['security'].setup()
        
        logger.info("✅ Sistemas inicializados")
    
    async def background_tasks(self) -> None:
        """Executa tasks em background"""
        await self.wait_until_ready()
        
        logger.info("⚙️ Iniciando tasks em background...")
        
        # Task de status
        self.loop.create_task(self.change_status())
        
        # Task de limpeza automática
        self.loop.create_task(self.auto_cleanup())
        
        # Task de backup automático
        self.loop.create_task(self.auto_backup())
    
    async def change_status(self) -> None:
        """Muda o status do bot periodicamente"""
        await self.wait_until_ready()
        
        statuses = [
            discord.Activity(type=discord.ActivityType.watching, name=f"{len(self.guilds)} servidores"),
            discord.Activity(type=discord.ActivityType.playing, name=f"{config.PREFIX}ajuda para ajuda"),
            discord.Activity(type=discord.ActivityType.listening, name="seus comandos"),
            discord.Activity(type=discord.ActivityType.watching, name="a segurança do servidor"),
            discord.Activity(type=discord.ActivityType.competing, name="CTFs")
        ]
        
        while not self.is_closed():
            for status in statuses:
                try:
                    await self.change_presence(activity=status)
                    await asyncio.sleep(300)  # 5 minutos
                except Exception as e:
                    logger.error(f"Erro ao mudar status: {e}")
                    await asyncio.sleep(60)
    
    async def auto_cleanup(self) -> None:
        """Limpeza automática de dados antigos"""
        await self.wait_until_ready()
        
        while not self.is_closed():
            try:
                # Limpar histórico da IA antigo
                if 'historico_ia' in db.data:
                    for user_id in list(db.data['historico_ia'].keys()):
                        if len(db.data['historico_ia'][user_id]) > 20:  # Mais de 20 mensagens
                            db.data['historico_ia'][user_id] = db.data['historico_ia'][user_id][-10:]
                    
                    db.save()
                
                # Limpar tickets fechados antigos
                if 'tickets' in db.data:
                    to_remove = []
                    for ticket_id, ticket_data in db.data['tickets'].items():
                        if ticket_data.get('status') == 'closed':
                            # Verificar se foi fechado há mais de 7 dias
                            from datetime import datetime
                            if 'closed_at' in ticket_data:
                                closed_date = datetime.fromisoformat(ticket_data['closed_at'])
                                if (datetime.now() - closed_date).days > 7:
                                    to_remove.append(ticket_id)
                    
                    for ticket_id in to_remove:
                        del db.data['tickets'][ticket_id]
                    
                    if to_remove:
                        db.save()
                
                await asyncio.sleep(3600)  # 1 hora
                
            except Exception as e:
                logger.error(f"Erro na limpeza automática: {e}")
                await asyncio.sleep(300)
    
    async def auto_backup(self) -> None:
        """Backup automático dos dados"""
        await self.wait_until_ready()
        
        import shutil
        import os
        from datetime import datetime
        
        while not self.is_closed():
            try:
                # Criar backup diário
                backup_dir = 'data/backups'
                if not os.path.exists(backup_dir):
                    os.makedirs(backup_dir)
                
                # Nome do arquivo com data
                date_str = datetime.now().strftime('%Y%m%d_%H%M')
                backup_file = os.path.join(backup_dir, f'backup_{date_str}.json')
                
                # Copiar arquivo de dados
                shutil.copy2('data/data.json', backup_file)
                
                # Limitar a 7 backups
                backups = sorted([f for f in os.listdir(backup_dir) if f.startswith('backup_')])
                if len(backups) > 7:
                    for old_backup in backups[:-7]:
                        os.remove(os.path.join(backup_dir, old_backup))
                
                logger.info(f"💾 Backup automático criado: {backup_file}")
                await asyncio.sleep(86400)  # 24 horas
                
            except Exception as e:
                logger.error(f"Erro no backup automático: {e}")
                await asyncio.sleep(3600)
    
    async def on_ready(self) -> None:
        """Evento quando o bot está pronto"""
        logger.info("=" * 60)
        logger.info(f"✅ Bot conectado como: {self.user.name}")
        logger.info(f"🆔 ID do Bot: {self.user.id}")
        logger.info(f"📊 Servidores: {len(self.guilds)}")
        logger.info(f"👥 Usuários: {sum(g.member_count for g in self.guilds)}")
        logger.info("=" * 60)
        
        # Verificar sistemas
        for system_name, system in self.systems.items():
            if system:
                logger.info(f"✅ Sistema {system_name} carregado")
            else:
                logger.warning(f"⚠️ Sistema {system_name} não carregado")
    
    async def close(self) -> None:
        """Fecha o bot corretamente"""
        logger.info("🔴 Finalizando bot...")
        
        # Salvar dados
        if self.db:
            self.db.save()
        
        # Fechar conexões
        await super().close()
        logger.info("👋 Bot finalizado")