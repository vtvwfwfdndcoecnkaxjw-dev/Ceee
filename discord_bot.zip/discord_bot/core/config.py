"""
CONFIGURAÇÕES GLOBAIS DO BOT
Todas as constantes e configurações centralizadas
"""

import os
from typing import Dict, Any
from dotenv import load_dotenv

load_dotenv()

# ========== CONFIGURAÇÕES PRINCIPAIS ==========
class Config:
    # TOKENS E API KEYS
    DISCORD_TOKEN = os.getenv('DISCORD_TOKEN')
    GROQ_API_KEY = os.getenv('GROQ_API_KEY')
    OWNER_ID = int(os.getenv('OWNER_ID', '0'))
    
    # PREFIXOS
    PREFIX = os.getenv('PREFIX', '!')
    
    # LIMITES E CONFIGURAÇÕES
    MAX_WARNINGS = int(os.getenv('MAX_WARNINGS', '3'))
    MAX_MESSAGES_PDF = 1000
    RATE_LIMIT_DELAY = 15  # segundos
    
    # CARGO CONFIGURAÇÕES
    CARGO_HIERARQUIA = {
        "Dono": 100,
        "Administrador": 90,
        "Moderador": 80,
        "Staff": 70,
        "Professor": 60,
        "Cyber Professor": 65,
        "Cyber Administrador": 85,
        "Cyber Staff": 75,
        "Membro": 10
    }
    
    # CARGO LINGUAGENS
    CARGO_LINGUAGENS = {
        "🐍 Python": "python",
        "☕ Java": "java", 
        "🟨 JavaScript": "javascript",
        "🔵 Golang": "golang",
        "🦀 Rust": "rust",
        "💜 C#": "csharp",
        "🔷 C/C++": "cpp",
        "🐘 PHP": "php",
        "💎 Ruby": "ruby",
        "🍎 Swift": "swift",
        "💚 Kotlin": "kotlin",
        "🐚 Bash/Shell": "bash"
    }
    
    # CARGO CYBER
    CARGO_CYBER = {
        "🎩 Ethical Hacker": "hacker",
        "🔍 Pentester": "pentester", 
        "🛡️ Blue Team": "blueteam",
        "🔴 Red Team": "redteam",
        "💰 Bug Hunter": "bughunter",
        "🏆 CTF Player": "ctf",
        "🕵️ OSINT": "osint",
        "🔧 Reverse Eng": "reverse",
        "💣 Exploit Dev": "exploit",
        "🦠 Malware Analyst": "malware"
    }
    
    # CONFIGURAÇÃO DE LOGS
    LOGS_CONFIG = {
        "entrada_saida": "👤・entrada-saida",
        "moderacao": "🛡️・mod-logs",
        "cargos": "⭐・cargo-logs",
        "advertencias": "⚠️・advertencias",
        "conquistas": "🏆・conquistas",
        "pontuacao": "📊・pontuacao"
    }
    
    # PALAVRAS MALICIOSAS PARA DETECÇÃO
    PALAVRAS_MALICIOSAS = {
        'raid', 'nuke', 'destroy', 'crash', 'massban', 'masskick',
        'lockdown', 'wipe', 'purge', 'deleteall', 'destroyall',
        'fuck', 'foder', 'fuder', 'foda', 'caralho', 'porra',
        'attack', 'atacar', 'invadir', 'hack', 'hackear',
        'exploit', 'vulnerability', 'vulnerabilidade',
        'bypass', 'contornar', 'burlar', 'driblar',
        'luna', 'nova', 'orbit', 'polar', 'quantum', 'phantom',
        'ghost', 'shadow', 'dark', 'black', 'void', 'abyss',
        'toxic', 'venom', 'poison', 'virus', 'malware',
        'panel', 'painel', 'tool', 'ferramenta', 'script',
        'botnet', 'network', 'rede', 'explorer', 'manager',
        '!massban', '!masskick', '!lock', '!unlock',
        '!delete', '!deletar', '!clearall', '!limpartudo',
        '!spam', '!flood', '!bomb', '!bomba',
        '!token', '!pass', '!password', '!senha',
        'webhook', 'massdm', 'mass_ping', 'everyone',
        'here', 'mass_mention', 'token_grabber',
        'selfbot', 'auto', 'automation', 'automatização',
        'lun4', 'n0va', '0rbit', 'qu4ntum', 'ph4nt0m',
        'gh0st', 'sh4d0w', 'd4rk', 'bl4ck', 'v01d',
        't0x1c', 'v3n0m', 'p01s0n', 'v1rus', 'm4lw4r3',
        'p4n3l', 'p41n3l', 't00l', 'f3rr4m3nt4',
        'b0tn3t', 'n3tw0rk', 'r3d3', '3xpl0r3r'
    }
    
    # PADRÕES SUSPEITOS
    PADROES_SUSPEITOS = {
        'comandos_rapidos': r'(\!.+?\s){5,}',
        'mencao_massiva': r'(@everyone|@here).*?(@everyone|@here)',
        'spam_caracteres': r'(.{2,}?)\1{5,}',
        'links_suspeitos': r'(discord\.gg|discordapp\.com)/[a-zA-Z0-9]+',
        'tokens': r'[a-zA-Z0-9]{24}\.[a-zA-Z0-9]{6}\.[a-zA-Z0-9]{27}'
    }
    
    # CONFIGURAÇÃO DE CANAIS AUTOMÁTICOS
    @classmethod
    def get_default_channels(cls) -> Dict[str, Any]:
        """Retorna configuração padrão de canais"""
        return {
            "self_roles": None,
            "entrada_saida": None,
            "mod_logs": None,
            "cargo_logs": None,
            "advertencias": None,
            "conquistas": None,
            "pontuacao": None,
            "tickets": None
        }
    
    @classmethod
    def validate_config(cls) -> bool:
        """Valida se todas as configurações necessárias estão presentes"""
        required = ['DISCORD_TOKEN']
        missing = [key for key in required if not getattr(cls, key)]
        
        if missing:
            print(f"❌ CONFIGURAÇÕES FALTANDO: {', '.join(missing)}")
            return False
        
        print("✅ Configurações validadas com sucesso!")
        return True

# Instância global de configuração
config = Config()