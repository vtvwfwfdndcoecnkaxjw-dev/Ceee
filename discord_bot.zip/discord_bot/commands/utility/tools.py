"""
FERAMENTAS ÚTEIS
Calculadora, tradução, lembretes, etc.
"""

import discord
from discord.ext import commands
import asyncio
import random
from datetime import datetime, timedelta
from typing import Optional

from core.config import config
from core.database import db
from core.logger import logger

class ToolCommands(commands.Cog):
    """Ferramentas úteis e utilitários"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command(name='calc')
    async def calculadora(self, ctx, *, expressao: str):
        """🧮 Calculadora simples"""
        try:
            # Remover espaços e validar caracteres
            expressao = expressao.replace(' ', '')
            caracteres_validos = set('0123456789+-*/.() ')
            
            if not all(c in caracteres_validos for c in expressao):
                await ctx.send("❌ Expressão contém caracteres inválidos")
                return
            
            # Calcular resultado
            resultado = eval(expressao)
            
            embed = discord.Embed(
                title="🧮 CALCULADORA",
                description=f"**Expressão:** `{expressao}`\n**Resultado:** `{resultado}`",
                color=0x0099ff
            )
            await ctx.send(embed=embed)
            
        except ZeroDivisionError:
            await ctx.send("❌ Erro: Divisão por zero")
        except Exception as e:
            await ctx.send(f"❌ Erro: Expressão inválida ({e})")
    
    @commands.command(name='traduzir')
    async def traduzir(self, ctx, idioma: str, *, texto: str):
        """🌍 Traduz texto (inglês/português)"""
        await ctx.typing()
        
        idiomas = {
            'pt': 'português',
            'en': 'inglês',
            'es': 'espanhol',
            'fr': 'francês',
            'de': 'alemão',
            'it': 'italiano',
            'ja': 'japonês',
            'ko': 'coreano',
            'zh': 'chinês'
        }
        
        if idioma not in idiomas:
            idiomas_disponiveis = ", ".join([f"`{k}` ({v})" for k, v in idiomas.items()])
            await ctx.send(f"❌ Idiomas disponíveis: {idiomas_disponiveis}")
            return
        
        groq_ai = self.bot.systems.get('groq_ai')
        if not groq_ai:
            await ctx.send("❌ Sistema de IA não disponível")
            return
        
        traducao = await groq_ai.traduzir_texto(texto, idioma)
        
        embed = discord.Embed(
            title="🌍 TRADUÇÃO",
            color=0x0099ff
        )
        embed.add_field(name="📝 Original", value=texto, inline=False)
        embed.add_field(name="🔤 Tradução", value=traducao, inline=False)
        embed.add_field(name="🎯 Idioma", value=idiomas[idioma].title(), inline=True)
        
        await ctx.send(embed=embed)
    
    @commands.command(name='lembrete')
    async def lembrete(self, ctx, minutos: int, *, mensagem: str):
        """⏰ Define um lembrete pessoal"""
        if minutos <= 0:
            await ctx.send("❌ O tempo deve ser maior que 0 minutos")
            return
        
        if minutos > 1440:  # 24 horas
            await ctx.send("❌ O tempo máximo é 1440 minutos (24 horas)")
            return
        
        await ctx.send(f"✅ Lembrete definido! Te avisarei em {minutos} minutos.")
        
        # Criar ID único para o lembrete
        lembrete_id = f"{ctx.author.id}_{int(datetime.now().timestamp())}"
        
        # Salvar lembrete no banco
        if 'lembretes_anuncios' not in db.data:
            db.data['lembretes_anuncios'] = {}
        
        db.data['lembretes_anuncios'][lembrete_id] = {
            "user_id": ctx.author.id,
            "channel_id": ctx.channel.id,
            "mensagem": mensagem,
            "executar_em": (datetime.now() + timedelta(minutes=minutos)).isoformat()
        }
        db.save()
        
        # Agendar execução
        await asyncio.sleep(minutos * 60)
        
        # Verificar se o lembrete ainda existe
        if lembrete_id in db.data.get('lembretes_anuncios', {}):
            try:
                # Enviar lembrete
                embed = discord.Embed(
                    title="⏰ LEMBRETE",
                    description=mensagem,
                    color=0xffd700,
                    timestamp=datetime.now()
                )
                embed.set_footer(text=f"Lembrete definido há {minutos} minutos")
                
                user = self.bot.get_user(ctx.author.id)
                if user:
                    await user.send(embed=embed)
                    await ctx.send(f"🔔 {ctx.author.mention}, lembrete enviado no seu privado!")
                else:
                    await ctx.send(f"🔔 {ctx.author.mention}, **LEMBRETE:** {mensagem}")
                
                # Remover lembrete
                del db.data['lembretes_anuncios'][lembrete_id]
                db.save()
                
            except discord.Forbidden:
                await ctx.send(f"🔔 {ctx.author.mention}, **LEMBRETE:** {mensagem}")
                del db.data['lembretes_anuncios'][lembrete_id]
                db.save()
    
    @commands.command(name='dado')
    async def dado(self, ctx, lados: int = 6):
        """🎲 Joga um dado"""
        if lados <= 0:
            await ctx.send("❌ O dado deve ter pelo menos 1 lado")
            return
        
        resultado = random.randint(1, lados)
        
        embed = discord.Embed(
            title="🎲 RESULTADO DO DADO",
            description=f"**Dado de {lados} lados:** 🎲 **{resultado}**",
            color=0x0099ff
        )
        
        # Adicionar efeito visual
        if resultado == 1:
            embed.add_field(name="🎯 Crítico", value="Rolou o mínimo!", inline=True)
        elif resultado == lados:
            embed.add_field(name="🎯 Crítico", value="Rolou o máximo!", inline=True)
        
        await ctx.send(embed=embed)
    
    @commands.command(name='moeda')
    async def moeda(self, ctx):
        """🪙 Cara ou coroa"""
        resultado = random.choice(["cara", "coroa"])
        emoji = "👑" if resultado == "coroa" else "😊"
        
        embed = discord.Embed(
            title="🪙 CARA OU COROA",
            description=f"**Resultado:** {emoji} **{resultado.upper()}**",
            color=0xffd700
        )
        
        # Estatísticas
        user_id = str(ctx.author.id)
        if 'coin_flips' not in db.data:
            db.data['coin_flips'] = {}
        
        if user_id not in db.data['coin_flips']:
            db.data['coin_flips'][user_id] = {'cara': 0, 'coroa': 0}
        
        db.data['coin_flips'][user_id][resultado] += 1
        db.save()
        
        total = db.data['coin_flips'][user_id]['cara'] + db.data['coin_flips'][user_id]['coroa']
        cara_percent = (db.data['coin_flips'][user_id]['cara'] / total) * 100 if total > 0 else 0
        coroa_percent = (db.data['coin_flips'][user_id]['coroa'] / total) * 100 if total > 0 else 0
        
        embed.add_field(
            name="📊 Suas Estatísticas",
            value=f"Cara: {db.data['coin_flips'][user_id]['cara']} ({cara_percent:.1f}%)\nCoroa: {db.data['coin_flips'][user_id]['coroa']} ({coroa_percent:.1f}%)",
            inline=True
        )
        
        await ctx.send(embed=embed)
    
    @commands.command(name='sorteio')
    @commands.has_permissions(manage_messages=True)
    async def sorteio(self, ctx, tempo: int = 60, *, premio: str):
        """🎉 Inicia um sorteio"""
        if tempo <= 0:
            await ctx.send("❌ O tempo deve ser maior que 0 segundos")
            return
        
        if tempo > 86400:  # 24 horas
            await ctx.send("❌ O tempo máximo é 86400 segundos (24 horas)")
            return
        
        embed = discord.Embed(
            title="🎉 SORTEIO!",
            description=f"**Prêmio:** {premio}\n**Tempo:** {tempo} segundos\n\nReaja com 🎉 para participar!",
            color=0xffd700,
            timestamp=datetime.now() + timedelta(seconds=tempo)
        )
        embed.set_footer(text="Sorteio termina em")
        
        mensagem = await ctx.send(embed=embed)
        await mensagem.add_reaction("🎉")
        
        await asyncio.sleep(tempo)
        
        # Recarregar mensagem para pegar reações atualizadas
        try:
            mensagem = await ctx.channel.fetch_message(mensagem.id)
        except:
            await ctx.send("❌ Erro ao buscar mensagem do sorteio")
            return
        
        reacao = discord.utils.get(mensagem.reactions, emoji="🎉")
        
        if reacao and reacao.count > 1:
            usuarios = []
            async for user in reacao.users():
                if not user.bot:
                    usuarios.append(user)
            
            if usuarios:
                vencedor = random.choice(usuarios)
                
                embed_vencedor = discord.Embed(
                    title="🎉 SORTEIO FINALIZADO!",
                    description=f"**Prêmio:** {premio}\n**Vencedor:** {vencedor.mention}",
                    color=0x00ff00,
                    timestamp=datetime.now()
                )
                
                await ctx.send(f"🎉 Parabéns {vencedor.mention}! Você ganhou: **{premio}**")
                await ctx.send(embed=embed_vencedor)
                
                # Registrar no banco
                if 'sorteios' not in db.data:
                    db.data['sorteios'] = []
                
                db.data['sorteios'].append({
                    "premio": premio,
                    "vencedor": vencedor.id,
                    "canal": ctx.channel.id,
                    "data": datetime.now().isoformat(),
                    "participantes": len(usuarios)
                })
                db.save()
            else:
                await ctx.send("❌ Ninguém participou do sorteio!")
        else:
            await ctx.send("❌ Ninguém participou do sorteio!")
    
    @commands.command(name='enquete')
    @commands.has_permissions(manage_messages=True)
    async def enquete(self, ctx, tempo: int = 3600, *, pergunta: str):
        """📊 Cria uma enquete com tempo"""
        if tempo <= 0:
            await ctx.send("❌ O tempo deve ser maior que 0 segundos")
            return
        
        if tempo > 604800:  # 7 dias
            await ctx.send("❌ O tempo máximo é 604800 segundos (7 dias)")
            return
        
        embed = discord.Embed(
            title="📊 ENQUETE",
            description=pergunta,
            color=0x0099ff,
            timestamp=datetime.now() + timedelta(seconds=tempo)
        )
        embed.add_field(name="⏰ Duração", value=f"{tempo//3600}h {(tempo%3600)//60}m", inline=True)
        embed.add_field(name="📝 Opções", value="✅ = Sim\n❌ = Não", inline=True)
        embed.set_footer(text="Enquete termina em")
        
        mensagem = await ctx.send(embed=embed)
        await mensagem.add_reaction("✅")
        await mensagem.add_reaction("❌")
        
        await asyncio.sleep(tempo)
        
        # Resultados
        try:
            mensagem = await ctx.channel.fetch_message(mensagem.id)
        except:
            await ctx.send("❌ Erro ao buscar mensagem da enquete")
            return
        
        sim = discord.utils.get(mensagem.reactions, emoji="✅")
        nao = discord.utils.get(mensagem.reactions, emoji="❌")
        
        count_sim = sim.count - 1 if sim else 0
        count_nao = nao.count - 1 if nao else 0
        total = count_sim + count_nao
        
        if total > 0:
            percent_sim = (count_sim / total) * 100
            percent_nao = (count_nao / total) * 100
            
            # Determinar vencedor
            vencedor = "Sim ✅" if count_sim > count_nao else "Não ❌" if count_nao > count_sim else "Empate"
            
            embed_resultado = discord.Embed(
                title="📊 RESULTADO DA ENQUETE",
                description=pergunta,
                color=0x00ff00
            )
            embed_resultado.add_field(name="✅ Sim", value=f"{count_sim} votos ({percent_sim:.1f}%)", inline=True)
            embed_resultado.add_field(name="❌ Não", value=f"{count_nao} votos ({percent_nao:.1f}%)", inline=True)
            embed_resultado.add_field(name="👥 Total", value=f"{total} votos", inline=True)
            embed_resultado.add_field(name="🏆 Resultado", value=vencedor, inline=True)
            
            await ctx.send(embed=embed_resultado)
            
            # Registrar no banco
            if 'enquetes' not in db.data:
                db.data['enquetes'] = []
            
            db.data['enquetes'].append({
                "pergunta": pergunta,
                "sim": count_sim,
                "nao": count_nao,
                "canal": ctx.channel.id,
                "data": datetime.now().isoformat(),
                "total_votos": total
            })
            db.save()
        else:
            await ctx.send("❌ Ninguém votou na enquete!")
    
    @commands.command(name='votacao_rapida')
    @commands.has_permissions(manage_messages=True)
    async def votacao_rapida(self, ctx, *, pergunta: str):
        """⚡ Votação rápida (sim/não)"""
        embed = discord.Embed(
            title="⚡ VOTAÇÃO RÁPIDA",
            description=pergunta,
            color=0x0099ff
        )
        embed.add_field(name="📊 Opções", value="✅ = Sim\n❌ = Não", inline=True)
        
        mensagem = await ctx.send(embed=embed)
        await mensagem.add_reaction("✅")
        await mensagem.add_reaction("❌")
    
    @commands.command(name='horario')
    async def horario(self, ctx, fuso: str = None):
        """🕐 Mostra horário atual"""
        from datetime import datetime
        import pytz
        
        if fuso:
            try:
                tz = pytz.timezone(fuso)
                hora_atual = datetime.now(tz)
                fuso_nome = fuso
            except:
                await ctx.send("❌ Fuso horário inválido. Use: `!horario [fuso]`\nExemplo: `!horario America/Sao_Paulo`")
                return
        else:
            hora_atual = datetime.now()
            fuso_nome = "Local"
        
        embed = discord.Embed(
            title="🕐 HORÁRIO ATUAL",
            color=0x0099ff,
            timestamp=datetime.now()
        )
        embed.add_field(name="📅 Data", value=hora_atual.strftime("%d/%m/%Y"), inline=True)
        embed.add_field(name="⏰ Hora", value=hora_atual.strftime("%H:%M:%S"), inline=True)
        embed.add_field(name="🌍 Fuso", value=fuso_nome, inline=True)
        
        # Fusos comuns
        fusos_comuns = {
            "America/Sao_Paulo": "🇧🇷 Brasil",
            "America/New_York": "🇺🇸 Nova York",
            "America/Los_Angeles": "🇺🇸 Los Angeles",
            "Europe/London": "🇬🇧 Londres",
            "Europe/Paris": "🇫🇷 Paris",
            "Asia/Tokyo": "🇯🇵 Tóquio",
            "Australia/Sydney": "🇦🇺 Sydney"
        }
        
        outros_horarios = []
        for fuso_code, nome in fusos_comuns.items():
            if fuso_code != fuso_nome:
                try:
                    tz = pytz.timezone(fuso_code)
                    hora = datetime.now(tz).strftime("%H:%M")
                    outros_horarios.append(f"{nome}: {hora}")
                except:
                    continue
        
        if outros_horarios:
            embed.add_field(name="🌎 Outros Fusos", value="\n".join(outros_horarios[:5]), inline=False)
        
        await ctx.send(embed=embed)
    
    @commands.command(name='clima')
    async def clima(self, ctx, *, cidade: str = None):
        """🌤️ Previsão do tempo (simulada)"""
        if not cidade:
            await ctx.send("❌ Especifique uma cidade: `!clima São Paulo`")
            return
        
        await ctx.typing()
        
        # Simulação de API de clima (em produção, integraria com OpenWeatherMap)
        import random
        
        temperaturas = {
            "são paulo": (22, 28),
            "rio de janeiro": (26, 32),
            "brasília": (24, 30),
            "salvador": (26, 31),
            "fortaleza": (27, 32),
            "belo horizonte": (23, 29),
            "curitiba": (18, 24),
            "porto alegre": (20, 26),
            "recife": (27, 32),
            "manaus": (26, 32)
        }
        
        cidade_lower = cidade.lower()
        if cidade_lower in temperaturas:
            temp_min, temp_max = temperaturas[cidade_lower]
        else:
            temp_min = random.randint(15, 25)
            temp_max = random.randint(26, 35)
        
        # Gerar descrição
        descricoes = [
            "☀️ Ensolarado",
            "⛅ Parcialmente nublado",
            "☁️ Nublado",
            "🌧️ Chuvoso",
            "⛈️ Tempestade",
            "🌦️ Chuviscos",
            "🌫️ Neblina",
            "❄️ Frio"
        ]
        
        descricao = random.choice(descricoes)
        
        # Umidade
        umidade = random.randint(40, 90)
        
        # Velocidade do vento
        vento = random.randint(5, 25)
        
        embed = discord.Embed(
            title=f"🌤️ CLIMA EM {cidade.upper()}",
            color=0x0099ff,
            timestamp=datetime.now()
        )
        embed.add_field(name="🌡️ Temperatura", value=f"{temp_min}°C - {temp_max}°C", inline=True)
        embed.add_field(name="📊 Condição", value=descricao, inline=True)
        embed.add_field(name="💧 Umidade", value=f"{umidade}%", inline=True)
        embed.add_field(name="💨 Vento", value=f"{vento} km/h", inline=True)
        embed.add_field(name="👁️ Visibilidade", value="10 km", inline=True)
        embed.add_field(name="🌅 Nascer do sol", value="06:00", inline=True)
        embed.add_field(name="🌇 Pôr do sol", value="18:30", inline=True)
        
        # Previsão para os próximos dias
        previsao = []
        for i in range(3):
            dia_temp = random.randint(temp_min - 2, temp_max + 2)
            previsao.append(f"Dia {i+1}: {dia_temp}°C")
        
        embed.add_field(name="📅 Próximos Dias", value="\n".join(previsao), inline=False)
        
        await ctx.send(embed=embed)

async def setup(bot):
    """Setup do cog de ferramentas"""
    await bot.add_cog(ToolCommands(bot))
    logger.info("✅ Comandos de ferramentas carregados")