"""
COMANDOS DE INFORMAÇÃO
Server info, perfil, ping, etc.
"""

import discord
from discord.ext import commands
from datetime import datetime

from core.config import config
from core.database import db
from core.logger import logger

class InfoCommands(commands.Cog):
    """Comandos de informação e utilidade"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command(name='server')
    async def server_info(self, ctx):
        """📊 Info do servidor"""
        guild = ctx.guild
        
        embed = discord.Embed(title=f"📊 {guild.name}", color=0x0099ff)
        
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        
        # Informações básicas
        embed.add_field(name="👥 Membros", value=guild.member_count, inline=True)
        embed.add_field(name="📁 Canais", value=len(guild.channels), inline=True)
        embed.add_field(name="⭐ Cargos", value=len(guild.roles), inline=True)
        embed.add_field(name="👑 Dono", value=guild.owner.mention, inline=True)
        embed.add_field(name="📅 Criado em", value=guild.created_at.strftime("%d/%m/%Y"), inline=True)
        embed.add_field(name="🆔 ID", value=guild.id, inline=True)
        
        # Estatísticas
        online = len([m for m in guild.members if m.status != discord.Status.offline])
        bots = len([m for m in guild.members if m.bot])
        
        embed.add_field(name="🟢 Online", value=online, inline=True)
        embed.add_field(name="🤖 Bots", value=bots, inline=True)
        embed.add_field(name="👤 Humanos", value=guild.member_count - bots, inline=True)
        
        # Níveis do servidor
        if guild.premium_tier > 0:
            embed.add_field(name="💎 Boost Level", value=guild.premium_tier, inline=True)
            embed.add_field(name="🚀 Boosts", value=guild.premium_subscription_count, inline=True)
        
        await ctx.send(embed=embed)
    
    @commands.command(name='ping')
    async def ping(self, ctx):
        """🏓 Mostra a latência do bot"""
        latency = round(self.bot.latency * 1000)
        
        embed = discord.Embed(
            title="🏓 PONG!",
            description=f"**Latência:** {latency}ms",
            color=0x00ff00 if latency < 100 else 0xff9900 if latency < 200 else 0xff0000
        )
        
        # Adicionar status
        if latency < 100:
            status = "✅ Excelente"
        elif latency < 200:
            status = "⚠️ Bom"
        else:
            status = "❌ Lento"
        
        embed.add_field(name="📶 Status", value=status, inline=True)
        
        await ctx.send(embed=embed)
    
    @commands.command(name='bot_id')
    async def mostrar_bot_id(self, ctx):
        """🆔 Mostra o ID do bot"""
        embed = discord.Embed(
            title="🤖 ID DO BOT",
            description=f"**ID do Bot:** `{self.bot.user.id}`\n**Nome:** {self.bot.user.name}",
            color=0x0099ff
        )
        await ctx.send(embed=embed)
    
    @commands.command(name='meu_id')
    async def mostrar_meu_id(self, ctx):
        """🆔 Mostra seu ID de usuário"""
        embed = discord.Embed(
            title="👤 SEU ID",
            description=f"**Seu ID:** `{ctx.author.id}`\n**Seu Nome:** {ctx.author.name}",
            color=0x0099ff
        )
        await ctx.send(embed=embed)
    
    @commands.command(name='perfil')
    async def perfil(self, ctx, member: discord.Member = None):
        """👤 Mostra perfil completo de um membro"""
        member = member or ctx.author
        
        embed = discord.Embed(
            title=f"👤 PERFIL - {member.name}",
            color=member.color if member.color else 0x0099ff
        )
        
        if member.avatar:
            embed.set_thumbnail(url=member.avatar.url)
        
        # Informações básicas
        embed.add_field(name="🆔 ID", value=member.id, inline=True)
        embed.add_field(name="📅 Entrou em", value=member.joined_at.strftime("%d/%m/%Y"), inline=True)
        embed.add_field(name="📅 Conta criada", value=member.created_at.strftime("%d/%m/%Y"), inline=True)
        
        # Status
        status_map = {
            discord.Status.online: "🟢 Online",
            discord.Status.idle: "🌙 Ausente",
            discord.Status.dnd: "⛔ Ocupado",
            discord.Status.offline: "⚫ Offline"
        }
        
        embed.add_field(name="📱 Status", value=status_map.get(member.status, "Desconhecido"), inline=True)
        
        # Cargos
        cargos = [cargo.mention for cargo in member.roles if cargo.name != "@everyone"]
        if cargos:
            embed.add_field(name=f"🎯 Cargos ({len(cargos)})", value=" ".join(cargos[:5]) + ("..." if len(cargos) > 5 else ""), inline=False)
        
        # Pontuação
        pontos = db.get_points(member.id)
        if pontos > 0:
            embed.add_field(name="⭐ Pontos", value=pontos, inline=True)
        
        # Advertências
        warnings = db.get_warnings(member.id)
        if warnings:
            embed.add_field(name="⚠️ Advertências", value=f"{len(warnings)}/{config.MAX_WARNINGS}", inline=True)
        
        # Convites
        invite_count = db.get_invite_count(member.id)
        if invite_count > 0:
            embed.add_field(name="📨 Convites", value=invite_count, inline=True)
        
        # Badges (se houver)
        if member.public_flags:
            badges = []
            if member.public_flags.staff:
                badges.append("👨‍💼 Staff do Discord")
            if member.public_flags.partner:
                badges.append("🤝 Parceiro")
            if member.public_flags.hypesquad:
                badges.append("🏠 HypeSquad")
            if member.public_flags.bug_hunter:
                badges.append("🐛 Bug Hunter")
            if member.public_flags.bug_hunter_level_2:
                badges.append("🐛🐛 Bug Hunter Nível 2")
            if member.public_flags.hypesquad_bravery:
                badges.append("🛡️ HypeSquad Bravery")
            if member.public_flags.hypesquad_brilliance:
                badges.append("🧠 HypeSquad Brilliance")
            if member.public_flags.hypesquad_balance:
                badges.append("⚖️ HypeSquad Balance")
            if member.public_flags.early_supporter:
                badges.append("🕐 Early Supporter")
            if member.public_flags.verified_bot_developer:
                badges.append("🤖 Desenvolvedor Verificado")
            
            if badges:
                embed.add_field(name="🏆 Badges", value="\n".join(badges), inline=False)
        
        await ctx.send(embed=embed)
    
    @commands.command(name='userinfo')
    async def userinfo(self, ctx, member: discord.Member = None):
        """ℹ️ Informações detalhadas do usuário"""
        member = member or ctx.author
        
        embed = discord.Embed(
            title=f"ℹ️ INFORMAÇÕES - {member.name}",
            color=member.color if member.color else 0x0099ff
        )
        
        if member.avatar:
            embed.set_thumbnail(url=member.avatar.url)
        
        embed.add_field(name="Nome", value=member.name, inline=True)
        embed.add_field(name="Discriminador", value=member.discriminator, inline=True)
        embed.add_field(name="ID", value=member.id, inline=True)
        
        # Status
        status_text = str(member.status).title()
        if member.status == discord.Status.online:
            status_text = "🟢 Online"
        elif member.status == discord.Status.idle:
            status_text = "🌙 Ausente"
        elif member.status == discord.Status.dnd:
            status_text = "⛔ Ocupado"
        elif member.status == discord.Status.offline:
            status_text = "⚫ Offline"
        
        embed.add_field(name="Status", value=status_text, inline=True)
        
        # Datas
        embed.add_field(name="Conta criada", value=member.created_at.strftime("%d/%m/%Y %H:%M"), inline=True)
        embed.add_field(name="Entrou em", value=member.joined_at.strftime("%d/%m/%Y %H:%M"), inline=True)
        
        # Cargos
        roles = [role.mention for role in member.roles if role != ctx.guild.default_role]
        embed.add_field(name=f"Cargos ({len(roles)})", value=" ".join(roles) if roles else "Nenhum", inline=False)
        
        # Atividade
        if member.activity:
            activity_type = "Jogando"
            if member.activity.type == discord.ActivityType.listening:
                activity_type = "Ouvindo"
            elif member.activity.type == discord.ActivityType.watching:
                activity_type = "Assistindo"
            elif member.activity.type == discord.ActivityType.streaming:
                activity_type = "Transmitindo"
            
            embed.add_field(name="🎮 Atividade", value=f"{activity_type}: {member.activity.name}", inline=False)
        
        await ctx.send(embed=embed)
    
    @commands.command(name='avatar')
    async def avatar(self, ctx, member: discord.Member = None):
        """🖼️ Mostra o avatar de um usuário"""
        member = member or ctx.author
        
        avatar_url = member.avatar.url if member.avatar else member.default_avatar.url
        
        embed = discord.Embed(
            title=f"🖼️ Avatar de {member.name}",
            color=0x0099ff,
            timestamp=datetime.now()
        )
        embed.set_image(url=avatar_url)
        embed.add_field(name="🔗 URL", value=f"[Clique aqui]({avatar_url})", inline=True)
        embed.add_field(name="👤 Usuário", value=member.mention, inline=True)
        
        await ctx.send(embed=embed)
    
    @commands.command(name='servericon')
    async def server_icon(self, ctx):
        """�️ Mostra o ícone do servidor"""
        if ctx.guild.icon:
            embed = discord.Embed(
                title=f"Ícone do Servidor: {ctx.guild.name}",
                color=0x0099ff,
                timestamp=datetime.now()
            )
            embed.set_image(url=ctx.guild.icon.url)
            embed.add_field(name="🔗 URL", value=f"[Clique aqui]({ctx.guild.icon.url})", inline=True)
            embed.add_field(name="📏 Tamanho", value=f"{ctx.guild.icon.width}x{ctx.guild.icon.height}", inline=True)
            
            await ctx.send(embed=embed)
        else:
            await ctx.send("❌ Este servidor não tem ícone")
    
    @commands.command(name='emoji_info')
    async def emoji_info(self, ctx, emoji: discord.Emoji):
        """😀 Mostra informações sobre um emoji"""
        embed = discord.Embed(
            title=f"Informações do Emoji: {emoji.name}",
            color=0x0099ff,
            timestamp=datetime.now()
        )
        embed.set_thumbnail(url=emoji.url)
        embed.add_field(name="🆔 ID", value=emoji.id, inline=True)
        embed.add_field(name="📅 Criado em", value=emoji.created_at.strftime("%d/%m/%Y"), inline=True)
        embed.add_field(name="👥 Disponível para", value="Todos" if emoji.available else "Restrito", inline=True)
        embed.add_field(name="🔗 URL", value=f"[Clique aqui]({emoji.url})", inline=True)
        
        # Quem adicionou
        async for entry in ctx.guild.audit_logs(limit=10, action=discord.AuditLogAction.emoji_create):
            if entry.target.id == emoji.id:
                embed.add_field(name="👤 Adicionado por", value=entry.user.mention, inline=True)
                break
        
        await ctx.send(embed=embed)
    
    @commands.command(name='estatisticas')
    async def estatisticas(self, ctx):
        """📈 Estatísticas do bot"""
        # Tempo de atividade
        uptime = datetime.now() - self.bot.start_time if hasattr(self.bot, 'start_time') else "Desconhecido"
        
        embed = discord.Embed(
            title="📈 ESTATÍSTICAS DO BOT",
            color=0x0099ff,
            timestamp=datetime.now()
        )
        
        # Informações gerais
        embed.add_field(name="🤖 Nome", value=self.bot.user.name, inline=True)
        embed.add_field(name="🆔 ID", value=self.bot.user.id, inline=True)
        embed.add_field(name="📊 Servidores", value=len(self.bot.guilds), inline=True)
        embed.add_field(name="👥 Usuários", value=sum(g.member_count for g in self.bot.guilds), inline=True)
        embed.add_field(name="📈 Comandos", value=len(self.bot.commands), inline=True)
        embed.add_field(name="⚡ Latência", value=f"{round(self.bot.latency * 1000)}ms", inline=True)
        
        # Uptime
        if isinstance(uptime, str):
            embed.add_field(name="⏰ Uptime", value=uptime, inline=True)
        else:
            days = uptime.days
            hours = uptime.seconds // 3600
            minutes = (uptime.seconds % 3600) // 60
            embed.add_field(name="⏰ Uptime", value=f"{days}d {hours}h {minutes}m", inline=True)
        
        # Versão
        import discord
        embed.add_field(name="📦 Discord.py", value=discord.__version__, inline=True)
        
        # Sistemas ativos
        active_systems = []
        for system_name, system in self.bot.systems.items():
            if system:
                active_systems.append(f"✅ {system_name}")
            else:
                active_systems.append(f"❌ {system_name}")
        
        embed.add_field(name="⚙️ Sistemas", value="\n".join(active_systems[:6]), inline=False)
        
        await ctx.send(embed=embed)

async def setup(bot):
    """Setup do cog de informações"""
    bot.start_time = datetime.now()  # Registrar tempo de início
    await bot.add_cog(InfoCommands(bot))
    logger.info("✅ Comandos de informação carregados")