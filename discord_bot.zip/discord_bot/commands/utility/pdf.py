"""
SISTEMA DE PDF
Criação e conversão de PDFs
"""

import discord
from discord.ext import commands
import asyncio
import aiohttp
import urllib.parse
from io import BytesIO
from datetime import datetime
from typing import Optional

from core.config import config
from core.logger import logger

class PDFCommands(commands.Cog):
    """Sistema completo de PDF"""
    
    def __init__(self, bot):
        self.bot = bot
        self.wkhtmltopdf_path = '/usr/bin/wkhtmltopdf'  # Altere para seu sistema
    
    @commands.command(name='pdf_canal')
    @commands.has_permissions(manage_messages=True)
    async def pdf_canal(self, ctx, limite: int = 100):
        """📄 Cria PDF com as mensagens do canal"""
        await ctx.typing()
        
        try:
            if limite <= 0:
                await ctx.send("❌ O limite deve ser maior que 0")
                return
            
            if limite > 1000:
                await ctx.send("❌ O limite máximo é 1000 mensagens")
                limite = 1000
            
            # Coletar mensagens
            messages = []
            async for message in ctx.channel.history(limit=limite):
                if not message.author.bot:  # Ignorar mensagens de bots
                    messages.append(message)
            
            messages.reverse()  # Ordem cronológica
            
            if not messages:
                await ctx.send("❌ Nenhuma mensagem encontrada para criar o PDF")
                return
            
            # Criar conteúdo HTML para o PDF
            html_content = f"""
            <html>
            <head>
                <meta charset="UTF-8">
                <title>Mensagens do Canal #{ctx.channel.name}</title>
                <style>
                    body {{ font-family: Arial, sans-serif; margin: 20px; }}
                    .message {{ border-bottom: 1px solid #eee; padding: 10px 0; }}
                    .author {{ font-weight: bold; color: #7289DA; }}
                    .timestamp {{ color: #666; font-size: 12px; }}
                    .content {{ margin: 5px 0; }}
                    .header {{ text-align: center; border-bottom: 2px solid #7289DA; padding-bottom: 10px; margin-bottom: 20px; }}
                    .attachments {{ margin-top: 10px; padding: 10px; background: #f5f5f5; border-radius: 5px; }}
                    .attachment {{ margin: 5px 0; }}
                </style>
            </head>
            <body>
                <div class="header">
                    <h1>💬 Mensagens do Canal #{ctx.channel.name}</h1>
                    <p>Servidor: {ctx.guild.name} | Gerado em: {datetime.now().strftime('%d/%m/%Y %H:%M')}</p>
                    <p>Total de mensagens: {len(messages)} | Período: {messages[0].created_at.strftime('%d/%m %H:%M')} - {messages[-1].created_at.strftime('%d/%m %H:%M')}</p>
                </div>
            """
            
            for message in messages:
                # Escapar HTML
                content = message.content.replace('<', '&lt;').replace('>', '&gt;')
                
                html_content += f"""
                <div class="message">
                    <div class="author">{message.author.display_name}</div>
                    <div class="timestamp">{message.created_at.strftime('%d/%m/%Y %H:%M')}</div>
                    <div class="content">{content}</div>
                """
                
                # Anexos
                if message.attachments:
                    html_content += '<div class="attachments">'
                    html_content += '<strong>Anexos:</strong>'
                    for attachment in message.attachments:
                        html_content += f'<div class="attachment">• {attachment.filename} ({attachment.size/1024:.1f} KB)</div>'
                    html_content += '</div>'
                
                html_content += '</div>'
            
            html_content += "</body></html>"
            
            # Gerar PDF (método 1: usando API online)
            try:
                pdf_data = await self.gerar_pdf_api(html_content)
            except:
                # Método 2: fallback para API pública
                pdf_data = await self.gerar_pdf_fallback(html_content)
            
            if not pdf_data or len(pdf_data) < 1000:
                await ctx.send("❌ Erro ao gerar PDF. Tente novamente.")
                return
            
            # Enviar PDF
            filename = f"mensagens_{ctx.channel.name}_{datetime.now().strftime('%Y%m%d_%H%M')}.pdf"
            
            embed = discord.Embed(
                title="📄 PDF GERADO COM SUCESSO!",
                description=f"**Canal:** #{ctx.channel.name}\n**Mensagens:** {len(messages)}\n**Período:** {messages[0].created_at.strftime('%d/%m %H:%M')} - {messages[-1].created_at.strftime('%d/%m %H:%M')}",
                color=0x00ff00
            )
            
            await ctx.send(embed=embed, file=discord.File(BytesIO(pdf_data), filename=filename))
            
        except Exception as e:
            logger.error(f"Erro ao gerar PDF: {e}")
            await ctx.send(f"❌ Erro ao gerar PDF: {e}")
    
    async def gerar_pdf_api(self, html_content: str) -> Optional[bytes]:
        """Gera PDF usando API online"""
        try:
            # Codificar HTML para URL
            html_encoded = urllib.parse.quote(html_content)
            
            # API pública de conversão HTML para PDF
            api_url = f"https://api.html2pdf.app/v1/generate?html={html_encoded}&apiKey=free"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(api_url, timeout=30) as response:
                    if response.status == 200:
                        return await response.read()
        except:
            pass
        return None
    
    async def gerar_pdf_fallback(self, html_content: str) -> Optional[bytes]:
        """Fallback para geração de PDF"""
        try:
            # Usar pdfkit se disponível
            import pdfkit
            
            # Configurar pdfkit
            config_pdf = pdfkit.configuration(wkhtmltopdf=self.wkhtmltopdf_path)
            
            # Gerar PDF
            pdf = pdfkit.from_string(html_content, False, configuration=config_pdf)
            return pdf
        except:
            pass
        
        # Último recurso: criar arquivo HTML
        try:
            html_content_bytes = html_content.encode('utf-8')
            return html_content_bytes
        except:
            return None
    
    @commands.command(name='web_to_pdf')
    async def web_to_pdf(self, ctx, url: str):
        """📄 Converte webpage para PDF instantaneamente"""
        await ctx.typing()
        
        try:
            if not url.startswith(('http://', 'https://')):
                url = 'https://' + url
            
            # Usar API pública
            api_url = f"https://api.html2pdf.app/v1/generate?url={urllib.parse.quote(url)}&apiKey=free"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(api_url, timeout=30) as response:
                    if response.status == 200:
                        pdf_data = await response.read()
                        
                        if len(pdf_data) > 1000:
                            filename = f"pagina_{datetime.now().strftime('%Y%m%d_%H%M')}.pdf"
                            
                            embed = discord.Embed(
                                title="📄 PÁGINA CONVERTIDA PARA PDF",
                                description=f"**URL:** {url}\n**Tamanho:** {len(pdf_data)/1024:.1f} KB",
                                color=0x00ff00
                            )
                            
                            await ctx.send(embed=embed, file=discord.File(BytesIO(pdf_data), filename=filename))
                        else:
                            await ctx.send("❌ Não foi possível converter a página")
                    else:
                        await ctx.send("❌ Erro ao converter a página")
                        
        except Exception as e:
            logger.error(f"Erro web_to_pdf: {e}")
            await ctx.send("❌ Erro ao processar a solicitação")
    
    @commands.command(name='topdf')
    async def topdf(self, ctx, url: str):
        """📄 Converta webpage para PDF (alias de web_to_pdf)"""
        await self.web_to_pdf(ctx, url)
    
    @commands.command(name='gerar_relatorio')
    @commands.has_permissions(administrator=True)
    async def gerar_relatorio(self, ctx, tipo: str = "membros"):
        """📊 Gera relatório em PDF do servidor"""
        await ctx.typing()
        
        try:
            if tipo == "membros":
                html_content = await self.criar_relatorio_membros(ctx.guild)
            elif tipo == "canais":
                html_content = await self.criar_relatorio_canais(ctx.guild)
            elif tipo == "atividade":
                html_content = await self.criar_relatorio_atividade(ctx.guild)
            else:
                await ctx.send("❌ Tipos disponíveis: `membros`, `canais`, `atividade`")
                return
            
            # Gerar PDF
            pdf_data = await self.gerar_pdf_api(html_content)
            
            if not pdf_data or len(pdf_data) < 1000:
                await ctx.send("❌ Erro ao gerar relatório PDF")
                return
            
            filename = f"relatorio_{tipo}_{ctx.guild.name}_{datetime.now().strftime('%Y%m%d_%H%M')}.pdf"
            
            embed = discord.Embed(
                title="📊 RELATÓRIO GERADO",
                description=f"**Tipo:** {tipo}\n**Servidor:** {ctx.guild.name}\n**Data:** {datetime.now().strftime('%d/%m/%Y %H:%M')}",
                color=0x0099ff
            )
            
            await ctx.send(embed=embed, file=discord.File(BytesIO(pdf_data), filename=filename))
            
        except Exception as e:
            logger.error(f"Erro ao gerar relatório: {e}")
            await ctx.send(f"❌ Erro ao gerar relatório: {e}")
    
    async def criar_relatorio_membros(self, guild: discord.Guild) -> str:
        """Cria relatório HTML de membros"""
        total_membros = guild.member_count
        online = len([m for m in guild.members if m.status != discord.Status.offline])
        bots = len([m for m in guild.members if m.bot])
        
        # Top cargos
        cargos_populares = []
        for role in guild.roles:
            if role.name != "@everyone":
                count = len([m for m in guild.members if role in m.roles])
                if count > 0:
                    cargos_populares.append((role.name, count))
        
        cargos_populares.sort(key=lambda x: x[1], reverse=True)
        
        html = f"""
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Relatório de Membros - {guild.name}</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .header {{ text-align: center; border-bottom: 2px solid #7289DA; padding-bottom: 20px; margin-bottom: 30px; }}
                .section {{ margin-bottom: 30px; }}
                .section-title {{ color: #7289DA; border-bottom: 1px solid #eee; padding-bottom: 10px; }}
                .stats {{ display: flex; flex-wrap: wrap; gap: 20px; }}
                .stat-card {{ background: #f5f5f5; padding: 15px; border-radius: 8px; flex: 1; min-width: 200px; }}
                .stat-value {{ font-size: 24px; font-weight: bold; color: #7289DA; }}
                .stat-label {{ color: #666; }}
                table {{ width: 100%; border-collapse: collapse; margin-top: 10px; }}
                th, td {{ padding: 10px; text-align: left; border-bottom: 1px solid #eee; }}
                th {{ background: #f5f5f5; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>📊 RELATÓRIO DE MEMBROS</h1>
                <h2>{guild.name}</h2>
                <p>Gerado em: {datetime.now().strftime('%d/%m/%Y %H:%M')}</p>
            </div>
            
            <div class="section">
                <h3 class="section-title">📈 ESTATÍSTICAS GERAIS</h3>
                <div class="stats">
                    <div class="stat-card">
                        <div class="stat-value">{total_membros}</div>
                        <div class="stat-label">Total de Membros</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value">{online}</div>
                        <div class="stat-label">Online</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value">{bots}</div>
                        <div class="stat-label">Bots</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value">{total_membros - bots}</div>
                        <div class="stat-label">Humanos</div>
                    </div>
                </div>
            </div>
            
            <div class="section">
                <h3 class="section-title">👥 DISTRIBUIÇÃO POR CARGO</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Cargo</th>
                            <th>Membros</th>
                            <th>Porcentagem</th>
                        </tr>
                    </thead>
                    <tbody>
        """
        
        for cargo, count in cargos_populares[:15]:
            percent = (count / total_membros) * 100
            html += f"""
                        <tr>
                            <td>{cargo}</td>
                            <td>{count}</td>
                            <td>{percent:.1f}%</td>
                        </tr>
            """
        
        html += """
                    </tbody>
                </table>
            </div>
            
            <div class="section">
                <h3 class="section-title">📅 MEMBROS RECENTES</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Membro</th>
                            <th>Entrou em</th>
                            <th>Conta criada</th>
                        </tr>
                    </thead>
                    <tbody>
        """
        
        # Membros mais recentes
        membros_recentes = sorted(guild.members, key=lambda m: m.joined_at, reverse=True)[:20]
        
        for member in membros_recentes:
            html += f"""
                        <tr>
                            <td>{member.name}</td>
                            <td>{member.joined_at.strftime('%d/%m/%Y') if member.joined_at else 'N/A'}</td>
                            <td>{member.created_at.strftime('%d/%m/%Y')}</td>
                        </tr>
            """
        
        html += """
                    </tbody>
                </table>
            </div>
            
            <div class="section">
                <h3 class="section-title">📊 RESUMO</h3>
                <p>• Servidor criado em: {guild.created_at.strftime('%d/%m/%Y')}</p>
                <p>• Dono: {guild.owner.name if guild.owner else 'N/A'}</p>
                <p>• Total de cargos: {len(guild.roles)}</p>
                <p>• Nível de boost: {guild.premium_tier}</p>
                <p>• Total de boosts: {guild.premium_subscription_count}</p>
            </div>
        </body>
        </html>
        """
        
        return html
    
    async def criar_relatorio_canais(self, guild: discord.Guild) -> str:
        """Cria relatório HTML de canais"""
        text_channels = len(guild.text_channels)
        voice_channels = len(guild.voice_channels)
        categories = len(guild.categories)
        
        html = f"""
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Relatório de Canais - {guild.name}</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .header {{ text-align: center; border-bottom: 2px solid #7289DA; padding-bottom: 20px; margin-bottom: 30px; }}
                .section {{ margin-bottom: 30px; }}
                .section-title {{ color: #7289DA; border-bottom: 1px solid #eee; padding-bottom: 10px; }}
                .stats {{ display: flex; flex-wrap: wrap; gap: 20px; }}
                .stat-card {{ background: #f5f5f5; padding: 15px; border-radius: 8px; flex: 1; min-width: 200px; }}
                .stat-value {{ font-size: 24px; font-weight: bold; color: #7289DA; }}
                .stat-label {{ color: #666; }}
                table {{ width: 100%; border-collapse: collapse; margin-top: 10px; }}
                th, td {{ padding: 10px; text-align: left; border-bottom: 1px solid #eee; }}
                th {{ background: #f5f5f5; }}
                .category {{ margin-bottom: 20px; padding: 15px; background: #f9f9f9; border-radius: 8px; }}
                .category-title {{ font-weight: bold; color: #7289DA; margin-bottom: 10px; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>📁 RELATÓRIO DE CANAIS</h1>
                <h2>{guild.name}</h2>
                <p>Gerado em: {datetime.now().strftime('%d/%m/%Y %H:%M')}</p>
            </div>
            
            <div class="section">
                <h3 class="section-title">📊 ESTATÍSTICAS</h3>
                <div class="stats">
                    <div class="stat-card">
                        <div class="stat-value">{text_channels}</div>
                        <div class="stat-label">Canais de Texto</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value">{voice_channels}</div>
                        <div class="stat-label">Canais de Voz</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value">{categories}</div>
                        <div class="stat-label">Categorias</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value">{text_channels + voice_channels}</div>
                        <div class="stat-label">Total de Canais</div>
                    </div>
                </div>
            </div>
        """
        
        # Categorias
        for category in guild.categories:
            html += f"""
            <div class="section">
                <div class="category">
                    <div class="category-title">📂 {category.name}</div>
            """
            
            # Canais na categoria
            for channel in category.channels:
                channel_type = "💬" if isinstance(channel, discord.TextChannel) else "🔊"
                html += f"""
                    <div>{channel_type} {channel.name} (Posição: {channel.position})</div>
                """
            
            html += """
                </div>
            </div>
            """
        
        # Canais sem categoria
        channels_without_category = [c for c in guild.channels if not c.category]
        if channels_without_category:
            html += """
            <div class="section">
                <h3 class="section-title">📝 CANAIS SEM CATEGORIA</h3>
            """
            
            for channel in channels_without_category:
                channel_type = "💬" if isinstance(channel, discord.TextChannel) else "🔊"
                html += f"""
                <div>{channel_type} {channel.name}</div>
                """
            
            html += "</div>"
        
        html += """
            <div class="section">
                <h3 class="section-title">📋 RESUMO</h3>
                <p>• Total de canais organizados: {sum(len(category.channels) for category in guild.categories)}</p>
                <p>• Canais sem categoria: {len(channels_without_category)}</p>
                <p>• Posição média dos canais: {sum(channel.position for channel in guild.channels) / len(guild.channels) if guild.channels else 0:.1f}</p>
            </div>
        </body>
        </html>
        """
        
        return html

async def setup(bot):
    """Setup do cog de PDF"""
    await bot.add_cog(PDFCommands(bot))
    logger.info("✅ Comandos de PDF carregados")