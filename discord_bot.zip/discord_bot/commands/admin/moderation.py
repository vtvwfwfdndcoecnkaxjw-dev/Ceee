"""
COMANDOS DE MODERAÇÃO
Ban, kick, mute, advertências e limpeza
"""

import discord
from discord.ext import commands
from datetime import datetime, timedelta
import asyncio

from core.config import config
from core.database import db
from core.logger import logger

from events.member_events import log_moderacao, log_advertencia

class ModerationCommands(commands.Cog):
    """Comandos de moderação completos"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command(name='ban')
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx, member: discord.Member, *, motivo="Não especificado"):
        """🔨 Bane um membro do servidor"""
        try:
            await member.ban(reason=f"{motivo} | Por: {ctx.author.name}")
            
            # Registrar ação do bot para segurança
            security_system = self.bot.systems.get('security')
            if security_system:
                await security_system.registrar_acao_bot(ctx.guild.id, 'ban')
            
            embed = discord.Embed(
                title="🔨 USUÁRIO BANIDO",
                description=f"**{member.name}** foi banido do servidor",
                color=0xff0000
            )
            embed.add_field(name="📝 Motivo", value=motivo, inline=False)
            embed.add_field(name="👮 Moderador", value=ctx.author.mention, inline=True)
            
            await ctx.send(embed=embed)
            await log_moderacao("BAN", ctx.author, member, motivo)
            
        except Exception as e:
            await ctx.send(f"❌ Erro ao banir usuário: {e}")
    
    @commands.command(name='banir')
    @commands.has_permissions(ban_members=True)
    async def banir_ia(self, ctx, member: discord.Member, *, motivo=None):
        """🔨 Banir usuário via comando de voz/texto com IA"""
        await ctx.typing()
        
        try:
            # Se não forneceu motivo, a IA gera um
            if not motivo:
                groq_ai = self.bot.systems.get('groq_ai')
                if groq_ai:
                    prompt = f"Gerar um motivo profissional para banir o usuário {member.name} do servidor Discord. Seja direto e objetivo."
                    motivo = await groq_ai.gerar_resposta(prompt)
                    motivo = f"Motivo automático: {motivo}"
                else:
                    motivo = "Violação das regras do servidor"
            
            # Executar ban
            await member.ban(reason=f"{motivo} | Por: {ctx.author.name}")
            
            # Registrar ação do bot para segurança
            security_system = self.bot.systems.get('security')
            if security_system:
                await security_system.registrar_acao_bot(ctx.guild.id, 'ban')
            
            embed = discord.Embed(
                title="🔨 USUÁRIO BANIDO",
                description=f"**{member.name}** foi banido do servidor",
                color=0xff0000
            )
            embed.add_field(name="📝 Motivo", value=motivo, inline=False)
            embed.add_field(name="👮 Moderador", value=ctx.author.mention, inline=True)
            embed.add_field(name="🆔 ID", value=member.id, inline=True)
            
            await ctx.send(embed=embed)
            await log_moderacao("BAN", ctx.author, member, motivo)
            
        except Exception as e:
            await ctx.send(f"❌ Erro ao banir usuário: {e}")
    
    @commands.command(name='kick')
    @commands.has_permissions(kick_members=True)
    async def kick(self, ctx, member: discord.Member, *, motivo="Não especificado"):
        """👢 Expulsa um membro do servidor"""
        try:
            await member.kick(reason=f"{motivo} | Por: {ctx.author.name}")
            
            embed = discord.Embed(
                title="👢 USUÁRIO EXPULSO",
                description=f"**{member.name}** foi expulso do servidor",
                color=0xff9900
            )
            embed.add_field(name="📝 Motivo", value=motivo, inline=False)
            embed.add_field(name="👮 Moderador", value=ctx.author.mention, inline=True)
            
            await ctx.send(embed=embed)
            await log_moderacao("KICK", ctx.author, member, motivo)
            
        except Exception as e:
            await ctx.send(f"❌ Erro ao expulsar usuário: {e}")
    
    @commands.command(name='mute')
    @commands.has_permissions(manage_roles=True)
    async def mute(self, ctx, member: discord.Member, tempo: str = "30m", *, motivo="Não especificado"):
        """🔇 Muta um membro por tempo determinado"""
        try:
            muted_role = discord.utils.get(ctx.guild.roles, name="Muted")
            
            if not muted_role:
                # Criar cargo Muted se não existir
                muted_role = await ctx.guild.create_role(name="Muted")
                
                # Aplicar permissões de mute em todos os canais
                for channel in ctx.guild.channels:
                    await channel.set_permissions(muted_role, speak=False, send_messages=False)
            
            # Converter tempo para segundos
            tempo_map = {"30m": 1800, "1h": 3600, "6h": 21600, "12h": 43200, "1d": 86400}
            segundos = tempo_map.get(tempo, 1800)
            
            await member.add_roles(muted_role)
            
            embed = discord.Embed(
                title="🔇 MEMBRO MUTADO",
                color=0xffff00
            )
            embed.add_field(name="👤 Membro", value=member.mention, inline=True)
            embed.add_field(name="⏰ Tempo", value=tempo, inline=True)
            embed.add_field(name="📝 Motivo", value=motivo, inline=False)
            embed.add_field(name="👮 Moderador", value=ctx.author.mention, inline=True)
            
            await ctx.send(embed=embed)
            await log_moderacao("MUTE", ctx.author, member, motivo, tempo)
            
            # Agendar remoção do mute
            await asyncio.sleep(segundos)
            if muted_role in member.roles:
                await member.remove_roles(muted_role)
                
        except Exception as e:
            await ctx.send(f"❌ Erro ao mutar usuário: {e}")
    
    @commands.command(name='unmute')
    @commands.has_permissions(manage_roles=True)
    async def unmute(self, ctx, member: discord.Member):
        """🔊 Remove mute de um membro"""
        try:
            muted_role = discord.utils.get(ctx.guild.roles, name="Muted")
            
            if not muted_role:
                await ctx.send("❌ Cargo 'Muted' não encontrado")
                return
            
            if muted_role not in member.roles:
                await ctx.send(f"❌ {member.mention} não está mutado")
                return
            
            await member.remove_roles(muted_role)
            await log_moderacao("UNMUTE", ctx.author, member, "Mute removido")
            
            embed = discord.Embed(
                title="🔊 MEMBRO DESMUTADO",
                color=0x00ff00
            )
            embed.add_field(name="👤 Membro", value=member.mention, inline=True)
            embed.add_field(name="👮 Moderador", value=ctx.author.mention, inline=True)
            
            await ctx.send(embed=embed)
            
        except Exception as e:
            await ctx.send(f"❌ Erro: {e}")
    
    @commands.command(name='advertir')
    @commands.has_permissions(manage_messages=True)
    async def advertir_ia(self, ctx, member: discord.Member, *, motivo=None):
        """⚠️ Advertir usuário via comando de voz/texto com IA"""
        await ctx.typing()
        
        try:
            # Se não forneceu motivo, a IA gera um
            if not motivo:
                groq_ai = self.bot.systems.get('groq_ai')
                if groq_ai:
                    prompt = f"Gerar um motivo profissional para advertir o usuário {member.name} em um servidor Discord. Seja educado mas firme."
                    motivo = await groq_ai.gerar_resposta(prompt)
                    motivo = f"Advertência automática: {motivo}"
                else:
                    motivo = "Comportamento inadequado"
            
            # Registrar advertência
            advertencia_num = db.add_warning(member.id, ctx.author.id, motivo)
            
            embed = discord.Embed(
                title=f"⚠️ ADVERTÊNCIA #{advertencia_num}",
                color=0xffff00
            )
            embed.add_field(name="👤 Membro", value=member.mention, inline=True)
            embed.add_field(name="👮 Moderador", value=ctx.author.mention, inline=True)
            embed.add_field(name="📝 Motivo", value=motivo, inline=False)
            embed.add_field(name="🚨 Status", value=f"{advertencia_num}/{config.MAX_WARNINGS} advertências", inline=True)
            
            if advertencia_num >= config.MAX_WARNINGS:
                embed.add_field(name="🔨 Próxima Ação", value="**BAN AUTOMÁTICO**", inline=True)
            
            await ctx.send(embed=embed)
            await log_advertencia(member, ctx.author, motivo, advertencia_num)
            
            # Ban automático se atingiu o limite
            if advertencia_num >= config.MAX_WARNINGS:
                await asyncio.sleep(2)
                await member.ban(reason=f"Limite de advertências atingido: {advertencia_num}/{config.MAX_WARNINGS}")
                await ctx.send(f"🚨 **{member.name}** foi banido automaticamente por atingir o limite de advertências!")
            
        except Exception as e:
            await ctx.send(f"❌ Erro ao advertir usuário: {e}")
    
    @commands.command(name='advertencias')
    @commands.has_permissions(manage_messages=True)
    async def advertencias(self, ctx, member: discord.Member = None):
        """📋 Ver advertências de um membro"""
        member = member or ctx.author
        warnings = db.get_warnings(member.id)
        
        if not warnings:
            await ctx.send(f"❌ {member.mention} não tem advertências")
            return
        
        embed = discord.Embed(
            title=f"⚠️ ADVERTÊNCIAS - {member.name}",
            color=0xffff00
        )
        
        for i, warning in enumerate(warnings, 1):
            moderador = ctx.guild.get_member(warning["moderador"])
            data = datetime.fromisoformat(warning["data"]).strftime("%d/%m/%Y %H:%M")
            
            embed.add_field(
                name=f"#{i} - {data}",
                value=f"**Motivo:** {warning['motivo']}\n**Por:** {moderador.mention if moderador else 'Usuário saiu'}",
                inline=False
            )
        
        embed.set_footer(text=f"Total: {len(warnings)}/{config.MAX_WARNINGS}")
        await ctx.send(embed=embed)
    
    @commands.command(name='remover_advertencia')
    @commands.has_permissions(manage_messages=True)
    async def remover_advertencia(self, ctx, member: discord.Member, numero_advertencia: int = None):
        """❌ Remove advertência de um membro"""
        warnings = db.get_warnings(member.id)
        
        if not warnings:
            await ctx.send("❌ Este membro não tem advertências")
            return
        
        if numero_advertencia is None:
            # Remove a última advertência
            warning_removed = warnings[-1]
            success = db.remove_warning(member.id, -1)
            
            if success:
                embed = discord.Embed(
                    title="❌ ADVERTÊNCIA REMOVIDA",
                    description=f"Última advertência de {member.mention} foi removida",
                    color=0x00ff00
                )
                embed.add_field(name="📝 Motivo Original", value=warning_removed["motivo"], inline=False)
                embed.add_field(name="👮 Moderador Original", 
                              value=ctx.guild.get_member(warning_removed["moderador"]).mention, 
                              inline=True)
                embed.add_field(name="🔄 Removido por", value=ctx.author.mention, inline=True)
                
                await ctx.send(embed=embed)
            else:
                await ctx.send("❌ Erro ao remover advertência")
        else:
            if numero_advertencia < 1 or numero_advertencia > len(warnings):
                await ctx.send(f"❌ Número de advertência inválido. Use de 1 a {len(warnings)}")
                return
            
            success = db.remove_warning(member.id, numero_advertencia - 1)
            
            if success:
                embed = discord.Embed(
                    title="❌ ADVERTÊNCIA REMOVIDA",
                    description=f"Advertência #{numero_advertencia} de {member.mention} foi removida",
                    color=0x00ff00
                )
                
                await ctx.send(embed=embed)
            else:
                await ctx.send("❌ Erro ao remover advertência")
    
    @commands.command(name='clear')
    @commands.has_permissions(manage_messages=True)
    async def clear(self, ctx, quantidade: int = None):
        """🧹 Limpa mensagens (INFINITAS)"""
        if not quantidade:
            await ctx.send("❌ Especifique a quantidade: `!clear 50`")
            return
        
        if quantidade <= 0:
            await ctx.send("❌ A quantidade deve ser maior que 0")
            return
        
        # Não há limite máximo - pode limpar infinitas mensagens
        deleted = await ctx.channel.purge(limit=quantidade + 1)
        
        # Registrar ação do bot para segurança
        security_system = self.bot.systems.get('security')
        if security_system:
            await security_system.registrar_acao_bot(ctx.guild.id, 'channel_delete')
        
        # Mensagem de confirmação que se auto-deleta
        msg = await ctx.send(f"✅ **{len(deleted) - 1} mensagens deletadas**", delete_after=5)
    
    @commands.command(name='kill')
    @commands.has_permissions(administrator=True)
    async def banir_membro(self, ctx, member: discord.Member, *, motivo="Violação grave das regras"):
        """💀 Banir membro com sistema de múltiplas denúncias"""
        try:
            # Simular múltiplas denúncias (3 tentativas)
            denuncias = []
            for i in range(3):
                try:
                    denuncia_msg = f"Denúncia #{i+1} processada"
                    denuncias.append(denuncia_msg)
                    await asyncio.sleep(0.2)
                except:
                    continue
            
            # Banir o membro
            await member.ban(reason=f"SYSTEM_KILL: {motivo} | Denúncias: {len(denuncias)}")
            
            # Registrar ação do bot para segurança
            security_system = self.bot.systems.get('security')
            if security_system:
                await security_system.registrar_acao_bot(ctx.guild.id, 'ban')
            
            embed = discord.Embed(
                title="💀 MEMBRO ELIMINADO",
                description=f"**{member.name}** foi banido do servidor",
                color=0xff0000
            )
            embed.add_field(name="📝 Motivo", value=motivo, inline=False)
            embed.add_field(name="🔨 Método", value="Sistema de múltiplas denúncias", inline=True)
            embed.add_field(name="📊 Denúncias", value=f"{len(denuncias)}/3 processadas", inline=True)
            embed.add_field(name="👮 Executado por", value=ctx.author.mention, inline=True)
            
            await ctx.send(embed=embed)
            await log_moderacao("KILL BAN", ctx.author, member, f"{motivo} | Denúncias: {len(denuncias)}")
            
        except Exception as e:
            await ctx.send(f"❌ Erro ao executar comando kill: {e}")
    
    @commands.command(name='quarentena')
    @commands.has_permissions(administrator=True)
    async def comando_quarentena(self, ctx, member: discord.Member, duracao_minutos: int = 60, 
                                *, motivo="Comportamento suspeito"):
        """🔒 Coloca usuário em quarentena"""
        await ctx.typing()
        
        try:
            security_system = self.bot.systems.get('security')
            if not security_system:
                await ctx.send("❌ Sistema de segurança não disponível")
                return
            
            success = await security_system.colocar_quarentena(member, duracao_minutos, motivo)
            
            if success:
                embed = discord.Embed(
                    title="🔒 USUÁRIO EM QUARENTENA",
                    description=f"**{member.mention}** foi colocado em quarentena",
                    color=0xff0000
                )
                embed.add_field(name="⏰ Duração", value=f"{duracao_minutos} minutos", inline=True)
                embed.add_field(name="📝 Motivo", value=motivo, inline=True)
                embed.add_field(name="👮 Ação por", value=ctx.author.mention, inline=True)
                
                await ctx.send(embed=embed)
            else:
                await ctx.send("❌ Erro ao colocar usuário em quarentena")
                
        except Exception as e:
            await ctx.send(f"❌ Erro: {e}")
    
    @commands.command(name='liberar_quarentena')
    @commands.has_permissions(administrator=True)
    async def liberar_quarentena(self, ctx, member: discord.Member):
        """🔓 Libera usuário da quarentena"""
        await ctx.typing()
        
        try:
            security_system = self.bot.systems.get('security')
            if not security_system:
                await ctx.send("❌ Sistema de segurança não disponível")
                return
            
            success = await security_system.remover_quarentena(member)
            
            if success:
                embed = discord.Embed(
                    title="🔓 USUÁRIO LIBERADO",
                    description=f"**{member.mention}** foi liberado da quarentena",
                    color=0x00ff00
                )
                await ctx.send(embed=embed)
            else:
                await ctx.send("❌ Usuário não está em quarentena ou erro ao liberar")
                
        except Exception as e:
            await ctx.send(f"❌ Erro: {e}")

async def setup(bot):
    """Setup do cog de moderação"""
    await bot.add_cog(ModerationCommands(bot))
    logger.info("✅ Comandos de moderação carregados")