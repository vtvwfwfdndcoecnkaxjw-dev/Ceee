"""
FUNÇÕES AUXILIARES
Helper functions para todo o bot
"""

import discord
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
import random
import string
import re

def format_time(seconds: int) -> str:
    """Formata segundos em string legível"""
    if seconds < 60:
        return f"{seconds} segundos"
    elif seconds < 3600:
        minutes = seconds // 60
        return f"{minutes} minutos"
    elif seconds < 86400:
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        return f"{hours} horas e {minutes} minutos"
    else:
        days = seconds // 86400
        hours = (seconds % 86400) // 3600
        return f"{days} dias e {hours} horas"

def generate_random_string(length: int = 8) -> str:
    """Gera string aleatória"""
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(length))

def create_progress_bar(value: float, max_value: float, length: int = 10) -> str:
    """Cria barra de progresso"""
    filled = int((value / max_value) * length)
    empty = length - filled
    return f"[{'█' * filled}{'░' * empty}] {value:.1f}/{max_value:.1f}"

def format_number(num: int) -> str:
    """Formata número com separadores de milhar"""
    return f"{num:,}".replace(",", ".")

def get_role_hierarchy(guild: discord.Guild, role_name: str) -> int:
    """Obtém hierarquia de um cargo"""
    from core.config import config
    return config.CARGO_HIERARQUIA.get(role_name, 0)

def is_url(text: str) -> bool:
    """Verifica se uma string é uma URL válida"""
    url_pattern = re.compile(
        r'^(?:http|ftp)s?://'  # http:// ou https://
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|'  # domínio
        r'localhost|'  # localhost
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}|'  # IP
        r'\[?[A-F0-9]*:[A-F0-9:]+\]?)'  # IPv6
        r'(?::\d+)?'  # porta
        r'(?:/?|[/?]\S+)$', re.IGNORECASE)
    
    return bool(url_pattern.match(text))

def split_embed_fields(embed: discord.Embed, fields: List[Dict[str, Any]]) -> List[discord.Embed]:
    """Divide campos de embed em múltiplos embeds se necessário"""
    embeds = [embed.copy()]
    current_embed = embeds[0]
    
    for field in fields:
        # Verificar se adicionar este campo excederia o limite
        if len(current_embed.fields) >= 25:
            # Criar novo embed
            new_embed = discord.Embed(
                title=f"{embed.title} (Continuação)",
                color=embed.color,
                description=embed.description
            )
            current_embed = new_embed
            embeds.append(current_embed)
        
        current_embed.add_field(**field)
    
    return embeds

def get_member_activity(member: discord.Member) -> Optional[str]:
    """Obtém atividade formatada do membro"""
    if not member.activity:
        return None
    
    activity = member.activity
    
    if isinstance(activity, discord.Game):
        return f"🎮 Jogando: {activity.name}"
    elif isinstance(activity, discord.Streaming):
        return f"📺 Transmitindo: {activity.name}"
    elif isinstance(activity, discord.Spotify):
        return f"🎵 Ouvindo: {activity.title} - {activity.artist}"
    elif isinstance(activity, discord.Activity):
        if activity.type == discord.ActivityType.listening:
            return f"🎧 Ouvindo: {activity.name}"
        elif activity.type == discord.ActivityType.watching:
            return f"📺 Assistindo: {activity.name}"
        elif activity.type == discord.ActivityType.competing:
            return f"🏆 Competindo em: {activity.name}"
        else:
            return f"📝 {activity.name}"
    
    return f"📝 {activity.name}"

def create_embed(title: str, description: str = "", color: int = 0x0099ff, **kwargs) -> discord.Embed:
    """Cria embed com configurações padrão"""
    embed = discord.Embed(
        title=title,
        description=description,
        color=color,
        timestamp=datetime.now()
    )
    
    if 'fields' in kwargs:
        for field in kwargs['fields']:
            embed.add_field(**field)
    
    if 'thumbnail' in kwargs:
        embed.set_thumbnail(url=kwargs['thumbnail'])
    
    if 'image' in kwargs:
        embed.set_image(url=kwargs['image'])
    
    if 'footer' in kwargs:
        embed.set_footer(text=kwargs['footer'])
    
    if 'author' in kwargs:
        embed.set_author(**kwargs['author'])
    
    return embed

def time_until(target_time: datetime) -> str:
    """Calcula tempo até uma data futura"""
    now = datetime.now()
    
    if target_time <= now:
        return "Já passou"
    
    diff = target_time - now
    
    days = diff.days
    hours, remainder = divmod(diff.seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    
    parts = []
    
    if days > 0:
        parts.append(f"{days} dia{'s' if days > 1 else ''}")
    if hours > 0:
        parts.append(f"{hours} hora{'s' if hours > 1 else ''}")
    if minutes > 0:
        parts.append(f"{minutes} minuto{'s' if minutes > 1 else ''}")
    if seconds > 0 and not parts:
        parts.append(f"{seconds} segundo{'s' if seconds > 1 else ''}")
    
    return ", ".join(parts) if parts else "Agora"

def calculate_level(xp: int) -> tuple:
    """Calcula nível e XP necessário baseado em XP total"""
    # Fórmula: nível^2 * 100
    level = 1
    xp_needed = 100
    
    while xp >= xp_needed:
        level += 1
        xp_needed = level ** 2 * 100
    
    xp_current = xp - ((level - 1) ** 2 * 100)
    xp_for_next = xp_needed - ((level - 1) ** 2 * 100)
    
    return level, xp_current, xp_for_next

def paginate_text(text: str, max_length: int = 2000) -> List[str]:
    """Divide texto longo em páginas"""
    if len(text) <= max_length:
        return [text]
    
    pages = []
    current_page = ""
    
    for line in text.split('\n'):
        if len(current_page) + len(line) + 1 > max_length:
            pages.append(current_page)
            current_page = line
        else:
            if current_page:
                current_page += '\n'
            current_page += line
    
    if current_page:
        pages.append(current_page)
    
    return pages

def get_relative_time(date: datetime) -> str:
    """Retorna tempo relativo (há X tempo)"""
    now = datetime.now()
    diff = now - date
    
    if diff.days > 365:
        years = diff.days // 365
        return f"há {years} ano{'s' if years > 1 else ''}"
    elif diff.days > 30:
        months = diff.days // 30
        return f"há {months} mês{'es' if months > 1 else ''}"
    elif diff.days > 0:
        return f"há {diff.days} dia{'s' if diff.days > 1 else ''}"
    elif diff.seconds > 3600:
        hours = diff.seconds // 3600
        return f"há {hours} hora{'s' if hours > 1 else ''}"
    elif diff.seconds > 60:
        minutes = diff.seconds // 60
        return f"há {minutes} minuto{'s' if minutes > 1 else ''}"
    else:
        return "agora mesmo"