"""
SISTEMA DE EMBEDS
Funções para criar embeds consistentes
"""

import discord
from datetime import datetime
from typing import Optional, List, Dict, Any

def success_embed(title: str, description: str = "") -> discord.Embed:
    """Cria embed de sucesso"""
    return discord.Embed(
        title=f"✅ {title}",
        description=description,
        color=0x00ff00,
        timestamp=datetime.now()
    )

def error_embed(title: str, description: str = "") -> discord.Embed:
    """Cria embed de erro"""
    return discord.Embed(
        title=f"❌ {title}",
        description=description,
        color=0xff0000,
        timestamp=datetime.now()
    )

def warning_embed(title: str, description: str = "") -> discord.Embed:
    """Cria embed de aviso"""
    return discord.Embed(
        title=f"⚠️ {title}",
        description=description,
        color=0xffff00,
        timestamp=datetime.now()
    )

def info_embed(title: str, description: str = "") -> discord.Embed:
    """Cria embed de informação"""
    return discord.Embed(
        title=f"ℹ️ {title}",
        description=description,
        color=0x0099ff,
        timestamp=datetime.now()
    )

def create_command_embed(command_name: str, description: str, usage: str, 
                        aliases: List[str] = None, examples: List[str] = None) -> discord.Embed:
    """Cria embed para documentação de comando"""
    embed = discord.Embed(
        title=f"🔧 Comando: {command_name}",
        description=description,
        color=0x7289DA,
        timestamp=datetime.now()
    )
    
    embed.add_field(name="📝 Uso", value=f"```{usage}```", inline=False)
    
    if aliases:
        embed.add_field(name="🔤 Aliases", value=", ".join(aliases), inline=True)
    
    if examples:
        examples_text = "\n".join([f"• `{ex}`" for ex in examples])
        embed.add_field(name="💡 Exemplos", value=examples_text, inline=False)
    
    embed.set_footer(text="Use !ajuda para ver todos os comandos")
    
    return embed

def create_list_embed(title: str, items: List[str], items_per_page: int = 10, 
                     page: int = 1, color: int = 0x0099ff) -> discord.Embed:
    """Cria embed para listar itens com paginação"""
    total_pages = (len(items) + items_per_page - 1) // items_per_page
    
    if page < 1 or page > total_pages:
        page = 1
    
    start_idx = (page - 1) * items_per_page
    end_idx = min(start_idx + items_per_page, len(items))
    
    embed = discord.Embed(
        title=f"{title} (Página {page}/{total_pages})",
        color=color,
        timestamp=datetime.now()
    )
    
    for i in range(start_idx, end_idx):
        embed.add_field(
            name=f"#{i + 1}",
            value=items[i],
            inline=False
        )
    
    embed.set_footer(text=f"Mostrando {start_idx + 1}-{end_idx} de {len(items)} itens")
    
    return embed

def create_table_embed(title: str, headers: List[str], rows: List[List[str]], 
                      color: int = 0x0099ff) -> discord.Embed:
    """Cria embed com tabela formatada"""
    embed = discord.Embed(
        title=title,
        color=color,
        timestamp=datetime.now()
    )
    
    # Criar tabela
    table = "```"
    table += " | ".join(headers) + "\n"
    table += "-" * (sum(len(h) for h in headers) + (len(headers) - 1) * 3) + "\n"
    
    for row in rows:
        table += " | ".join(str(cell) for cell in row) + "\n"
    
    table += "```"
    
    embed.description = table
    
    return embed

def create_stats_embed(title: str, stats: Dict[str, Any], color: int = 0x0099ff) -> discord.Embed:
    """Cria embed para estatísticas"""
    embed = discord.Embed(
        title=f"📊 {title}",
        color=color,
        timestamp=datetime.now()
    )
    
    for key, value in stats.items():
        embed.add_field(name=key, value=str(value), inline=True)
    
    return embed

def create_profile_embed(member: discord.Member, data: Dict[str, Any]) -> discord.Embed:
    """Cria embed de perfil de usuário"""
    embed = discord.Embed(
        title=f"👤 Perfil de {member.name}",
        color=member.color if member.color else 0x0099ff,
        timestamp=datetime.now()
    )
    
    if member.avatar:
        embed.set_thumbnail(url=member.avatar.url)
    
    # Informações básicas
    embed.add_field(name="🆔 ID", value=member.id, inline=True)
    embed.add_field(name="📅 Entrou em", value=member.joined_at.strftime("%d/%m/%Y"), inline=True)
    
    # Dados personalizados
    for key, value in data.items():
        if value:  # Apenas adicionar se tiver valor
            embed.add_field(name=key, value=value, inline=True)
    
    return embed